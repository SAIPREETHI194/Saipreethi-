function showAlert() {
  alert("Hello! You clicked the button.");
}